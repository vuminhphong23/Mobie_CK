import 'package:http/http.dart' as http;
import 'dart:convert';

class City {
  final String name;
  final String stateCode;

  City({
    required this.name,
    required this.stateCode,
  });

  factory City.fromJson(Map<String, dynamic> json) {
    return City(
      name: json['name'],
      stateCode: json['state_code'],
    );
  }

   Future<List<City>> fetchStates(String countryName) async {
    try {
      var result = 'https://countriesnow.space/api/v0.1/countries/states/q?country=' + countryName;
      var url = Uri.parse(result);

      var response = await http.get(url);
      if (response.statusCode == 200) {
        var jsonData = jsonDecode(response.body);
        var statesData = jsonData['data']['states'] as List;

        List<City> states = statesData.map((state) => City.fromJson(state)).toList();

        return states;
      } else {
        throw Exception('Failed to fetch states: ${response.reasonPhrase}');
      }
    } catch (error) {
      throw Exception('Failed to fetch states: $error');
    }
  }

  // Future<List<City>> fetchCities(String countryName) async {
  //   try {
  //     var url = Uri.parse('https://countriesnow.space/api/v0.1/countries');
  //     var response = await http.get(url);
  //
  //     if (response.statusCode == 200) {
  //       var jsonData = jsonDecode(response.body);
  //       var countriesData = jsonData['data'] as List;
  //
  //       var cities = <City>[];
  //
  //       for (var countryData in countriesData) {
  //         if (countryData['country'] == countryName) {
  //           var countryCities = countryData['cities'] as List;
  //           for (var city in countryCities) {
  //             cities.add(City(name: city.toString(), latestPopulation: {})); // Đây là giá trị mặc định, bạn có thể thay đổi nếu cần
  //           }
  //           break; // Kết thúc vòng lặp sau khi đã tìm thấy quốc gia
  //         }
  //       }
  //
  //       return cities;
  //     } else {
  //       throw Exception('Failed to fetch cities: ${response.reasonPhrase}');
  //     }
  //   } catch (error) {
  //     throw Exception('Failed to fetch cities: $error');
  //   }
  // }
  //
  //
  // Future<Map<String, String>> _getLatestPopulationCity(String cityName) async {
  //   try {
  //     var url = Uri.parse('https://countriesnow.space/api/v0.1/countries/population/cities');
  //     var response = await http.get(url);
  //
  //     if (response.statusCode == 200) {
  //       var jsonData = jsonDecode(response.body);
  //       var citiesData = jsonData['data'] as List;
  //       var count = 0;
  //       for (var cityData in citiesData) {
  //         if (cityData['city'] == cityName) {
  //           var populationCounts = cityData['populationCounts'] as List;
  //           if (populationCounts.isNotEmpty) {
  //             populationCounts.sort((a, b) => b['year'].compareTo(a['year']));
  //             var latestPopulation = populationCounts.first;
  //             return {
  //               'year': latestPopulation['year'].toString(),
  //               'population': latestPopulation['value'].toString(),
  //             };
  //           }
  //           if (count == 10) {
  //             // Nếu đã đủ 20 thành phố, dừng vòng lặp
  //             break;
  //           }
  //         }
  //       }
  //       throw Exception('Population data not found for city: $cityName');
  //     } else {
  //       throw Exception('Failed to fetch population data: ${response.reasonPhrase}');
  //     }
  //   } catch (error) {
  //     throw Exception('Failed to fetch population data: $error');
  //   }
  // }
  //
  // // Phương thức lấy danh sách thành phố của quốc gia từ API
  // Future<List<City>> fetchCountryCities(String countryName) async {
  //   try {
  //     var url = Uri.parse('https://countriesnow.space/api/v0.1/countries/population/cities');
  //     var response = await http.get(url);
  //
  //     if (response.statusCode == 200) {
  //       var jsonData = jsonDecode(response.body);
  //       var citiesData = jsonData['data'] as List;
  //
  //       var cities = <City>[];
  //       var count = 0;
  //
  //       for (var cityData in citiesData) {
  //         if (cityData['country'] == countryName) {
  //           var cityName = cityData['city'];
  //           var latestPopulation = await _getLatestPopulationCity(cityName);
  //           cities.add(City(name: cityName, latestPopulation: latestPopulation)); // Thêm thông tin dân số của năm gần nhất vào danh sách thành phố
  //           count++; // Tăng biến đếm lên sau khi thêm thành phố vào danh sách
  //
  //           if (count == 10) {
  //             // Nếu đã đủ 20 thành phố, dừng vòng lặp
  //             break;
  //           }
  //         }
  //       }
  //
  //       return cities; // Trả về danh sách các thành phố
  //     } else {
  //       throw Exception('Failed to fetch city data: ${response.reasonPhrase}');
  //     }
  //   } catch (error) {
  //     throw Exception('Failed to fetch city data: $error');
  //   }
  // }
}
