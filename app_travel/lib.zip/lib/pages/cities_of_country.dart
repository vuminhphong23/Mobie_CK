import 'package:flutter/material.dart';
import '../models/city_model.dart';

class CityListScreen extends StatelessWidget {
  final String countryName;

  CityListScreen({required this.countryName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cities in $countryName'),
      ),
      body: FutureBuilder(
        future: City(name: '',stateCode: '').fetchStates(countryName),
        builder: (context, AsyncSnapshot<List<City>> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            var cities = snapshot.data!;
            return ListView.builder(
              itemCount: cities.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(cities[index].name),
                  subtitle: Text('StateCode: ${cities[index].stateCode}'),
                );
              },
            );
          }
        },
      ),
    );
  }
}
