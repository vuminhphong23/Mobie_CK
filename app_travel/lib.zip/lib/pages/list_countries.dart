// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
//
// import '../models/city_model.dart';
//
// class CityPopulationPage extends StatefulWidget {
//   @override
//   _CityPopulationPageState createState() => _CityPopulationPageState();
// }
//
// class _CityPopulationPageState extends State<CityPopulationPage> {
//   late List<CityData> _cityDataList;
//   final String cityName = 'Ha Ka'; // Thành phố cố định
//
//   @override
//   void initState() {
//     super.initState();
//     _cityDataList = [];
//     _getCitiesPopulation(cityName);
//   }
//
//   Future<void> _getCitiesPopulation(String cityName) async {
//     try {
//       var url = Uri.parse('https://countriesnow.space/api/v0.1/countries/population/cities');
//       var response = await http.get(url);
//
//       if (response.statusCode == 200) {
//         var jsonData = jsonDecode(response.body);
//         var data = jsonData['data'] as List;
//
//         List<CityData> cityDataList = [];
//         data.forEach((cityData) {
//           var cityDataObject = CityData.fromJson(cityData, 'url_to_flag');
//           if (cityDataObject.city.toLowerCase() == cityName.toLowerCase()) {
//             cityDataList.add(cityDataObject);
//           }
//         });
//
//         setState(() {
//           _cityDataList = cityDataList;
//         });
//       } else if (response.statusCode == 301 || response.statusCode == 302 || response.statusCode == 308) {
//         // If redirection occurs, get redirected URL and make the request again
//         var redirectUrl = response.headers['location'];
//         if (redirectUrl != null) {
//           var redirectResponse = await http.get(Uri.parse(redirectUrl));
//           if (redirectResponse.statusCode == 200) {
//             // Process the response similarly as before
//           } else {
//             print('Failed to fetch data after redirection: ${redirectResponse.reasonPhrase}');
//           }
//         } else {
//           print('Failed to get redirect URL');
//         }
//       } else {
//         print('Failed to fetch data: ${response.reasonPhrase}');
//       }
//     } catch (error) {
//       print('Failed to fetch data: $error');
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('City Populations'),
//       ),
//       body: _cityDataList.isNotEmpty
//           ? ListView.builder(
//         itemCount: _cityDataList.length,
//         itemBuilder: (context, index) {
//           var cityData = _cityDataList[index];
//           return ListTile(
//             title: Text('${cityData.city}, ${cityData.country}'),
//             subtitle: Text('Population: ${cityData.populationCounts.first['value']}'),
//           );
//         },
//       )
//           : Center(
//         child: CircularProgressIndicator(),
//       ),
//     );
//   }
// }
