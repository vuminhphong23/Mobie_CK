import 'package:flutter/material.dart';
import '../models/country_model.dart';
import 'country.dart'; // Import class CountryData từ file country_data.dart

class SearchPage extends StatefulWidget {
  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  TextEditingController _searchController = TextEditingController();
  List<CountryData> _allCountries = [];
  List<CountryData> _searchResults = [];
  bool _isSearching = false;

  @override
  void initState() {
    super.initState();
    _loadCountries();
  }

  Future<void> _loadCountries() async {
    _allCountries = await CountryData.fetchListCountriesData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Country Search'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Enter country name',
                border: OutlineInputBorder(),
              ),
              onChanged: (value) {
                _searchCountries(value);
              },
            ),
            SizedBox(height: 10),
            _isSearching
                ? Expanded(
              child: _searchResults.isEmpty
                  ? Center(child: Text('No results found'))
                  : ListView.builder(
                itemCount: _searchResults.length,
                itemBuilder: (BuildContext context, int index) {
                  return ListTile(
                    title: Text(_searchResults[index].country),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CountryDetail(countryName: _searchResults[index].country),
                        ),
                      );
                    },
                  );
                },
              ),
            )
                : Container(),
          ],
        ),
      ),
    );
  }

  void _searchCountries(String query) {
    setState(() {
      _searchResults = _allCountries
          .where((country) => country.country.toLowerCase().contains(query.toLowerCase()))
          .toList();
      _isSearching = query.isNotEmpty;
    });
  }
}